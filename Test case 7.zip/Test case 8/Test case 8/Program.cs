﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

class Program
{
    static void Main()
    {
        // Initialize the Chrome WebDriver
        IWebDriver driver = new ChromeDriver();

        try
        {
            // Navigate to the bus booking website
            driver.Navigate().GoToUrl("https://www.examplebusbooking.com");

            // Log in or initiate a booking (similar to previous examples)

            // After successfully booking a seat, navigate to the reservation details page
            driver.Navigate().GoToUrl("https://www.examplebusbooking.com/reservation/12345"); // Replace with a valid reservation URL

            // Verify that the reservation details page is displayed (customize based on the website's behavior)
            if (driver.Url.Contains("https://www.examplebusbooking.com/reservation/"))
            {
                Console.WriteLine("Reservation details page test passed.");

                // Find and click on the "Track Bus" or similar button/link
                IWebElement trackBusButton = driver.FindElement(By.Id("track_bus_button"));
                trackBusButton.Click();

                // Simulate the initiation of real-time bus tracking (e.g., navigating to a new page or opening a tracking map)

                // Verify that the real-time tracking map or information page is displayed (customize based on the website's behavior)
                if (driver.Url.Contains("https://www.examplebusbooking.com/realtime_tracking"))
                {
                    Console.WriteLine("Real-time bus tracking test passed.");
                }
                else
                {
                    Console.WriteLine("Real-time bus tracking test failed.");
                }
            }
            else
            {
                Console.WriteLine("Reservation details page test failed.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("An error occurred: " + ex.Message);
        }
        finally
        {
            // Close the WebDriver (you can add additional logic here)
            driver.Quit();
        }
    }
}
