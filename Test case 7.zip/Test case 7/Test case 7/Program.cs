﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

class Program
{
    static void Main()
    {
        // Initialize the Chrome WebDriver
        IWebDriver driver = new ChromeDriver();

        try
        {
            // Navigate to the bus booking website
            driver.Navigate().GoToUrl("https://www.examplebusbooking.com");

            // Log in or initiate a booking (similar to previous examples)

            // After successfully booking a seat, navigate to the reservation details page
            driver.Navigate().GoToUrl("https://www.examplebusbooking.com/reservation/12345"); // Replace with a valid reservation URL

            // Verify that the reservation details page is displayed (customize based on the website's behavior)
            if (driver.Url.Contains("https://www.examplebusbooking.com/reservation/"))
            {
                Console.WriteLine("Reservation details page test passed.");

                // Find and click on the "Print Ticket" or "Generate Ticket" button/link
                IWebElement printTicketButton = driver.FindElement(By.Id("print_ticket_button"));
                printTicketButton.Click();

                // Simulate the ticket generation process (e.g., navigating to a new page with ticket details)

                // Verify that the ticket details are displayed (customize based on the website's behavior)
                if (driver.Url.Contains("https://www.examplebusbooking.com/ticket/"))
                {
                    Console.WriteLine("Ticket generation test passed.");

                    // Check if necessary ticket information is present on the page
                    IWebElement passengerName = driver.FindElement(By.Id("passenger_name"));
                    IWebElement seatNumber = driver.FindElement(By.Id("seat_number"));
                    IWebElement departureInfo = driver.FindElement(By.Id("departure_info"));

                    // Verify that passenger names, seat numbers, and departure details are displayed
                    if (!string.IsNullOrEmpty(passengerName.Text) && !string.IsNullOrEmpty(seatNumber.Text) && !string.IsNullOrEmpty(departureInfo.Text))
                    {
                        Console.WriteLine("Ticket contains necessary information.");
                    }
                    else
                    {
                        Console.WriteLine("Ticket is missing necessary information.");
                    }
                }
                else
                {
                    Console.WriteLine("Ticket generation test failed.");
                }
            }
            else
            {
                Console.WriteLine("Reservation details page test failed.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("An error occurred: " + ex.Message);
        }
        finally
        {
            // Close the WebDriver (you can add additional logic here)
            driver.Quit();
        }
    }
}
